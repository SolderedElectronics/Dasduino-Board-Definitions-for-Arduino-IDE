/**
 **************************************************
 *
 * @file        WS2812-SOLDERED.cpp
 * @brief       Intentionally blank
 *
 *
 * @copyright GNU General Public License v3.0
 * @authors     @ soldered.com
 ***************************************************/
