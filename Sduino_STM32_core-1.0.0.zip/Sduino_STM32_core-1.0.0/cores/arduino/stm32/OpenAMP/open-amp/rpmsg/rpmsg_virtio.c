#ifdef VIRTIOCON

#include "virtio_config.h"
#include "open-amp/lib/rpmsg/rpmsg_virtio.c"

#endif /* VIRTIOCON */
