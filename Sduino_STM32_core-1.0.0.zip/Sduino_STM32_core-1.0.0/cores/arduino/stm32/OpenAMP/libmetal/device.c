#ifdef VIRTIOCON

#include "libmetal/lib/device.c"

#endif /* VIRTIOCON */
