# Compile test sketches

These sketches, along with the examples, are used as part of the CI testing of this core. These are not included umder examples because they do not exemplify anything profound or educational. The point is that the CI should automatically attempt to compile them for all boards, and any failures to do so would indicate a regression.
