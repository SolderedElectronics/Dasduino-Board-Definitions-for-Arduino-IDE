#ifdef STM32H7xx
  #include "stm32h7xx_ll_delayblock.c"
#endif
#ifdef STM32MP1xx
  #include "stm32mp1xx_ll_delayblock.c"
#endif
