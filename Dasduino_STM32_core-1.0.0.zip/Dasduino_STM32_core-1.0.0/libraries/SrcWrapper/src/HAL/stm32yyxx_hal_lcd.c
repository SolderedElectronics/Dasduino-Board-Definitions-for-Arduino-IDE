#ifdef STM32L0xx
  #include "stm32l0xx_hal_lcd.c"
#endif
#ifdef STM32L1xx
  #include "stm32l1xx_hal_lcd.c"
#endif
#ifdef STM32L4xx
  #include "stm32l4xx_hal_lcd.c"
#endif
#ifdef STM32WBxx
  #include "stm32wbxx_hal_lcd.c"
#endif
