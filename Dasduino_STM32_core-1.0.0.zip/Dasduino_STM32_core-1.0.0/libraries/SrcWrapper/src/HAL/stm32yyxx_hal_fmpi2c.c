#ifdef STM32F4xx
  #include "stm32f4xx_hal_fmpi2c.c"
#endif
