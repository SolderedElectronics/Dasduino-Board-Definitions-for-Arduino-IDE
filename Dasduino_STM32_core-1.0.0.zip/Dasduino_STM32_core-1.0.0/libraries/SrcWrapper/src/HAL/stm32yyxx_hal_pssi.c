#ifdef STM32H7xx
  #include "stm32h7xx_hal_pssi.c"
#endif
#ifdef STM32L4xx
  #include "stm32l4xx_hal_pssi.c"
#endif
