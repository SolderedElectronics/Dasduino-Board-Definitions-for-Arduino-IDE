#ifdef STM32MP1xx
  #include "stm32mp1xx_hal_ipcc.c"
#endif
#ifdef STM32WBxx
  #include "stm32wbxx_hal_ipcc.c"
#endif
